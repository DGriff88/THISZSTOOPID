
"""
Unified Strategy File
Includes:
- EMA crossover
- RSI mean reversion
- Seasonal strategy (Memorial Day → Labor Day)
- Options evaluation strategy
"""

import pandas as pd
import numpy as np
from datetime import datetime
from ta.trend import EMAIndicator
from ta.momentum import RSIIndicator

### --- EMA Crossover Strategy ---
def ema_crossover_signal(df, fast=9, slow=21):
    ema_fast = EMAIndicator(df["close"], fast).ema_indicator()
    ema_slow = EMAIndicator(df["close"], slow).ema_indicator()
    buy = (ema_fast > ema_slow) & (ema_fast.shift(1) <= ema_slow.shift(1))
    sell = (ema_fast < ema_slow) & (ema_fast.shift(1) >= ema_slow.shift(1))
    return buy.fillna(False), sell.fillna(False), {'strategy': 'EMA_CROSSOVER'}

### --- RSI Mean Reversion Strategy ---
def rsi_mean_reversion(df, period=14, low=30, high=70):
    rsi = RSIIndicator(df["close"], period).rsi()
    buy = rsi < low
    sell = rsi > high
    return buy.fillna(False), sell.fillna(False), {'strategy': 'RSI_MEAN_REVERSION'}

### --- Seasonal Strategy (Memorial Day to Labor Day) ---
def seasonal_signal(df, symbol):
    seasonal_stocks = ['CHTR', 'BIO', 'NDAQ']
    start_dates = {'CHTR': '06-20', 'BIO': '07-01', 'NDAQ': '07-30'}
    memorial_day = '05-25'
    labor_day = '09-01'

    now = datetime.now()
    md = now.strftime('%m-%d')

    if not (memorial_day <= md <= labor_day):
        return False, False, {'strategy': 'SEASONAL', 'reason': 'Outside seasonal window'}

    if symbol not in seasonal_stocks or md < start_dates.get(symbol, '00-00'):
        return False, False, {'strategy': 'SEASONAL', 'reason': 'Symbol not active in season'}

    if len(df) < 10:
        return False, False, {'strategy': 'SEASONAL', 'reason': 'Insufficient data'}

    df['sma_5'] = df['close'].rolling(5).mean()
    df['sma_10'] = df['close'].rolling(10).mean()
    df['rsi'] = RSIIndicator(df['close'], 14).rsi()
    latest = df.iloc[-1]

    buy = latest['sma_5'] > latest['sma_10'] and latest['rsi'] > 50
    sell = latest['sma_5'] < latest['sma_10'] and latest['rsi'] < 50
    return buy, sell, {'strategy': 'SEASONAL'}

### --- Options Evaluation Strategy ---
def evaluate_call_option(underlying_price, strike_price, option_price, days_to_expiry, delta_target=0.30, max_cost_pct=0.025):
    cost_pct = option_price / underlying_price
    breakeven_price = strike_price + option_price
    breakeven_pct = (breakeven_price - underlying_price) / underlying_price

    moneyness = underlying_price / strike_price
    if moneyness > 1.1:
        delta = 0.9
    elif moneyness > 1.0:
        delta = 0.7
    elif moneyness > 0.95:
        delta = 0.5
    elif moneyness > 0.9:
        delta = 0.3
    else:
        delta = 0.1

    should_buy = delta >= delta_target and cost_pct <= max_cost_pct
    analysis = {
        'underlying_price': underlying_price,
        'strike_price': strike_price,
        'option_price': option_price,
        'cost_pct': cost_pct,
        'breakeven_pct': breakeven_pct,
        'delta': delta,
        'should_buy': should_buy
    }
    return should_buy, analysis
