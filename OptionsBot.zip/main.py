
import sys
import pandas as pd
from strategies import ema_crossover_signal, rsi_mean_reversion, seasonal_signal
from data import get_historical_data  # assumes this function exists

def run_strategies(symbol):
    print(f"🧠 Running strategies for: {symbol}")
    df = get_historical_data(symbol, period='30d', interval='1h')

    if df is None or df.empty:
        print("⚠️ No data for", symbol)
        return

    # Run all strategies
    results = []

    buy, sell, meta = ema_crossover_signal(df)
    if buy.iloc[-1]:
        results.append(("BUY", "EMA", meta))
    if sell.iloc[-1]:
        results.append(("SELL", "EMA", meta))

    buy, sell, meta = rsi_mean_reversion(df)
    if buy.iloc[-1]:
        results.append(("BUY", "RSI", meta))
    if sell.iloc[-1]:
        results.append(("SELL", "RSI", meta))

    buy, sell, meta = seasonal_signal(df, symbol)
    if buy:
        results.append(("BUY", "SEASONAL", meta))
    if sell:
        results.append(("SELL", "SEASONAL", meta))

    if results:
        print(f"✅ Trade signals for {symbol}:")
        for r in results:
            signal, strat, meta = r
            print(f"   {signal} | Strategy: {strat} | Details: {meta}")
    else:
        print(f"❌ No signals for {symbol}")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        symbol = sys.argv[1].upper()
        run_strategies(symbol)
    else:
        print("Please provide a ticker symbol (e.g. python main.py TSLA)")
