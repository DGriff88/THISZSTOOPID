
# 🧠 OptionsBot – Clean Build

## 📁 Structure
```
OptionsBot/
├── main.py               # Entry point for scanning + signal generation
├── run_live.py           # Placeholder for live integration
├── strategies/
│   ├── __init__.py
│   ├── options.py
│   ├── select.py
│   ├── seasonal.py
│   └── test.py
├── scanner/
│   └── scan.py
├── utils/
│   ├── app.py, auth.py, ...
├── data/
│   └── feeds.py
├── logs/
├── outputs/
└── README.md
```

## ▶️ How to Run
```bash
python main.py NVDA
```

## 🧪 What It Does
- Pulls options data via Yahoo Finance
- Applies rule engine from `rules.py`
- Runs selected strategies
- Prints actionable signals in the terminal
- Outputs logs to `logs/`

## 🛠️ To Add Later
- Schwab live integration via `auth.py` and `client.py`
- UI or browser dashboard
- Telegram/webhook alerts
