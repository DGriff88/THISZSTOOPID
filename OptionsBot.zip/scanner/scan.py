"""
Options Scanner Module
Scans tickers for potential options trades using technical indicators.
Outputs trade suggestions in structured JSON format.
"""

import yfinance as yf
import datetime
import json
import pandas as pd
import numpy as np

def calculate_indicators(df):
    df["EMA_9"] = df["Close"].ewm(span=9, adjust=False).mean()
    df["EMA_21"] = df["Close"].ewm(span=21, adjust=False).mean()
    df["RSI"] = compute_rsi(df["Close"], 14)
    df["MACD"], df["MACD_signal"] = compute_macd(df["Close"])
    df["VWAP"] = (df["Volume"] * (df["High"] + df["Low"]) / 2).cumsum() / df["Volume"].cumsum()
    return df

def compute_rsi(series, period=14):
    delta = series.diff()
    gain = np.where(delta > 0, delta, 0)
    loss = np.where(delta < 0, -delta, 0)
    avg_gain = pd.Series(gain).rolling(window=period).mean()
    avg_loss = pd.Series(loss).rolling(window=period).mean()
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def compute_macd(series, fast=12, slow=26, signal=9):
    exp1 = series.ewm(span=fast, adjust=False).mean()
    exp2 = series.ewm(span=slow, adjust=False).mean()
    macd = exp1 - exp2
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    return macd, signal_line

def scan_ticker(ticker, shares=1):
    end = datetime.datetime.now()
    start = end - datetime.timedelta(days=30)
    data = yf.download(ticker, start=start, end=end, progress=False)
    if data.empty:
        return {"ticker": ticker, "error": "No data retrieved"}
    
    data = calculate_indicators(data)

    last = data.iloc[-1]
    signal = ""
    setup = ""
    skip_reason = ""

    if last["EMA_9"] > last["EMA_21"] and last["RSI"] > 50 and last["MACD"] > last["MACD_signal"]:
        signal = "bullish"
        setup = "Put_Credit_Spread"
    elif last["EMA_9"] < last["EMA_21"] and last["RSI"] < 50 and last["MACD"] < last["MACD_signal"]:
        signal = "bearish"
        setup = "Call_Credit_Spread"
    else:
        skip_reason = "Indicators not aligned"
    
    return {
        "ticker": ticker,
        "setup": setup,
        "direction": signal,
        "contract": "Auto-calc pending",
        "debit": 40,
        "max_loss": 40,
        "max_profit": 60,
        "rr": 1.5,
        "confidence": 3 if signal else 0,
        "why_now": f"Signal = {signal}" if signal else "",
        "do_not_trade_if": "EMA reversal or RSI divergence",
        "skip_reason": skip_reason
    }
