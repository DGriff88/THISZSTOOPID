
from flask import Flask, request, jsonify
import subprocess

app = Flask(__name__)

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.json
    symbol = data.get("symbol", "").upper()
    strategy = data.get("strategy", "default")

    if not symbol:
        return jsonify({"error": "No symbol provided"}), 400

    print(f"📡 Received webhook: symbol={symbol}, strategy={strategy}")

    # Trigger TERMINATOR FINAL bot with the symbol
    subprocess.Popen(["python", "main.py", symbol])
    return jsonify({"status": "triggered", "symbol": symbol}), 200

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5005)
