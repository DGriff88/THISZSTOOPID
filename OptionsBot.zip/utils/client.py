import os
import json as _json
import requests
from dotenv import load_dotenv
from config import BASE_URL as CFG_BASE_URL, TOKENS_FILE as CFG_TOKENS_FILE

# Load environment variables from .env file
load_dotenv()

# Prefer config.py defaults; allow env override
BASE_URL = os.getenv("BASE_URL", CFG_BASE_URL).rstrip("/")
TOKENS_FILE = os.getenv("TOKENS_FILE", CFG_TOKENS_FILE)


def _read_bearer_token(tokens_path: str) -> str:
    """Read bearer token from tokens file. Supports raw token or JSON with access_token."""
    try:
        with open(tokens_path, 'r', encoding='utf-8') as f:
            raw = f.read().strip()
            if not raw:
                raise RuntimeError("tokens file is empty")
            try:
                obj = _json.loads(raw)
                token = obj.get("access_token") or obj.get("accessToken")
                if token:
                    return token.strip()
            except Exception:
                # not JSON; assume raw token
                pass
            return raw
    except FileNotFoundError:
        raise RuntimeError(f"Tokens file not found at {tokens_path}. Run auth flow or set DRY_RUN/OFFLINE_MODE.")


def _req(method: str, path: str, params=None, json=None, timeout=30):
    clean_path = str(path or "").lstrip("/")
    url = f"{BASE_URL}/{clean_path}"
    bearer = _read_bearer_token(TOKENS_FILE)
    headers = {
        'Authorization': f'Bearer {bearer}',
        'Accept': 'application/json'
    }
    r = requests.request(method, url, headers=headers, params=params, json=json, timeout=timeout)
    r.raise_for_status()
    return r.json() if r.content else None


def api_get(path: str, params=None):
    return _req('GET', path, params=params)


def api_post(path: str, json=None):
    return _req('POST', path, json=json)