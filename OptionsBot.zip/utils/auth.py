"""
auth.py (patched) — uses REDIRECT_URI, not CALLBACK_URL.
If you only want to *capture* the auth code with a tiny server, run schwab_auth.py instead.
This file demonstrates exchanging the authorization code for tokens using requests-oauthlib.

Requirements:
  pip install python-dotenv requests-oauthlib

Environment (.env):
  CLIENT_ID=...
  CLIENT_SECRET=...
  REDIRECT_URI=http://127.0.0.1:8080/callback
  TOKEN_URL=https://api.schwabapi.com/oauth2/token
  TOKENS_FILE=./tokens.json
"""

import os, json
from pathlib import Path
from dotenv import load_dotenv
from requests_oauthlib import OAuth2Session

def exchange_code_for_token(authorization_response: str) -> str:
    load_dotenv()
    client_id = os.getenv("CLIENT_ID")
    client_secret = os.getenv("CLIENT_SECRET")
    redirect_uri = os.getenv("REDIRECT_URI", "http://127.0.0.1:8080/callback")
    token_url = os.getenv("TOKEN_URL", "https://api.schwabapi.com/oauth2/token")
    tokens_file = Path(os.getenv("TOKENS_FILE", "./tokens.json")).expanduser()

    if not client_id or not client_secret:
        raise RuntimeError("CLIENT_ID/CLIENT_SECRET missing in .env")

    # OAuth session pinned to our redirect
    sess = OAuth2Session(client_id, redirect_uri=redirect_uri)

    token = sess.fetch_token(
        token_url,
        authorization_response=authorization_response,
        client_secret=client_secret,
        include_client_id=True,
    )

    tokens_file.write_text(json.dumps(token, indent=2), encoding="utf-8")
    return f"Authentication successful. Tokens saved to {tokens_file}"
    
if __name__ == "__main__":
    # Example usage: paste the full redirected URL here when prompted.
    url = input("Paste the full redirected URL (after login): ").strip()
    print(exchange_code_for_token(url))
