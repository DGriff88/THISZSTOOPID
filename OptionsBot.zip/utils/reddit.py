"""
Reddit Integration - Market Sentiment and Trading Ideas
Uses FlimtoFlam app to monitor trading subreddits for sentiment analysis
"""

import praw
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import logging
import re
import time

logger = logging.getLogger(__name__)

class RedditIntegration:
    """
    Reddit integration for market sentiment analysis and trading ideas.
    
    Uses FlimtoFlam app credentials:
    - Client ID: 8jkzCTWZ4tMiDAsqu_2ltQ
    - Secret: EqvLbAs-zkJemu-yjlvg1A7zUanfBg
    - Redirect URI: http://localhost
    """
    
    def __init__(self, config):
        self.config = config
        self.enabled = config.get('REDDIT_ENABLED', False)
        self.client_id = config.get('REDDIT_CLIENT_ID', '8jkzCTWZ4tMiDAsqu_2ltQ')
        self.client_secret = config.get('REDDIT_CLIENT_SECRET', 'EqvLbAs-zkJemu-yjlvg1A7zUanfBg')
        self.redirect_uri = config.get('REDDIT_REDIRECT_URI', 'http://localhost')
        self.user_agent = config.get('REDDIT_USER_AGENT', 'Schwabbot/1.0')
        
        # Trading subreddits to monitor
        self.subreddits = [
            'wallstreetbets',
            'investing', 
            'stocks',
            'options',
            'daytrading',
            'algotrading',
            'pennystocks',
            'stockmarket'
        ]
        
        # Keywords for sentiment analysis
        self.bullish_keywords = [
            'bullish', 'moon', 'rocket', 'to the moon', '🚀', '💎', 'diamond hands',
            'hodl', 'buy', 'long', 'call', 'puts', 'short squeeze', 'gamma squeeze',
            'fomo', 'breakout', 'uptrend', 'rally', 'surge', 'jump', 'spike'
        ]
        
        self.bearish_keywords = [
            'bearish', 'dump', 'crash', 'bear market', 'recession', 'sell',
            'short', 'put', 'downtrend', 'decline', 'drop', 'fall', 'plunge',
            'correction', 'bubble', 'overvalued', 'sell off', 'panic'
        ]
        
        self.reddit = None
        if self.enabled:
            self._initialize_reddit()
    
    def _initialize_reddit(self):
        """Initialize Reddit API client."""
        try:
            self.reddit = praw.Reddit(
                client_id=self.client_id,
                client_secret=self.client_secret,
                user_agent=self.user_agent,
                redirect_uri=self.redirect_uri
            )
            logger.info("Reddit API initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Reddit API: {e}")
            self.reddit = None
    
    def get_market_sentiment(self, hours_back: int = 24) -> Dict:
        """
        Analyze market sentiment from Reddit posts and comments.
        
        Args:
            hours_back: How many hours back to analyze
            
        Returns:
            Dictionary with sentiment analysis
        """
        if not self.enabled or not self.reddit:
            return {'error': 'Reddit integration not enabled'}
        
        try:
            sentiment_data = {
                'timestamp': datetime.now().isoformat(),
                'hours_analyzed': hours_back,
                'subreddits': self.subreddits,
                'total_posts': 0,
                'total_comments': 0,
                'bullish_count': 0,
                'bearish_count': 0,
                'neutral_count': 0,
                'sentiment_score': 0.0,
                'hot_topics': [],
                'mentioned_stocks': {}
            }
            
            cutoff_time = datetime.now() - timedelta(hours=hours_back)
            
            for subreddit_name in self.subreddits:
                try:
                    subreddit = self.reddit.subreddit(subreddit_name)
                    
                    # Get hot posts
                    for post in subreddit.hot(limit=25):
                        if datetime.fromtimestamp(post.created_utc) < cutoff_time:
                            continue
                            
                        sentiment_data['total_posts'] += 1
                        
                        # Analyze post title and content
                        title_sentiment = self._analyze_text_sentiment(post.title)
                        content_sentiment = self._analyze_text_sentiment(post.selftext)
                        
                        # Combine sentiment
                        post_sentiment = (title_sentiment + content_sentiment) / 2
                        
                        if post_sentiment > 0.1:
                            sentiment_data['bullish_count'] += 1
                        elif post_sentiment < -0.1:
                            sentiment_data['bearish_count'] += 1
                        else:
                            sentiment_data['neutral_count'] += 1
                        
                        # Extract mentioned stocks
                        stocks = self._extract_stock_symbols(post.title + ' ' + post.selftext)
                        for stock in stocks:
                            if stock not in sentiment_data['mentioned_stocks']:
                                sentiment_data['mentioned_stocks'][stock] = 0
                            sentiment_data['mentioned_stocks'][stock] += 1
                        
                        # Get comments
                        post.comments.replace_more(limit=0)  # Don't load more comments
                        for comment in post.comments.list():
                            if datetime.fromtimestamp(comment.created_utc) < cutoff_time:
                                continue
                                
                            sentiment_data['total_comments'] += 1
                            comment_sentiment = self._analyze_text_sentiment(comment.body)
                            
                            if comment_sentiment > 0.1:
                                sentiment_data['bullish_count'] += 1
                            elif comment_sentiment < -0.1:
                                sentiment_data['bearish_count'] += 1
                            else:
                                sentiment_data['neutral_count'] += 1
                            
                            # Extract stocks from comments
                            stocks = self._extract_stock_symbols(comment.body)
                            for stock in stocks:
                                if stock not in sentiment_data['mentioned_stocks']:
                                    sentiment_data['mentioned_stocks'][stock] = 0
                                sentiment_data['mentioned_stocks'][stock] += 1
                    
                    time.sleep(1)  # Rate limiting
                    
                except Exception as e:
                    logger.warning(f"Error processing subreddit {subreddit_name}: {e}")
                    continue
            
            # Calculate overall sentiment score
            total_mentions = sentiment_data['bullish_count'] + sentiment_data['bearish_count'] + sentiment_data['neutral_count']
            if total_mentions > 0:
                sentiment_data['sentiment_score'] = (
                    (sentiment_data['bullish_count'] - sentiment_data['bearish_count']) / total_mentions
                )
            
            # Sort mentioned stocks by frequency
            sentiment_data['mentioned_stocks'] = dict(
                sorted(sentiment_data['mentioned_stocks'].items(), 
                      key=lambda x: x[1], reverse=True)[:20]
            )
            
            return sentiment_data
            
        except Exception as e:
            logger.error(f"Error in market sentiment analysis: {e}")
            return {'error': str(e)}
    
    def _analyze_text_sentiment(self, text: str) -> float:
        """
        Analyze sentiment of text using keyword matching.
        
        Returns:
            Sentiment score between -1 (bearish) and 1 (bullish)
        """
        if not text:
            return 0.0
        
        text_lower = text.lower()
        
        bullish_count = sum(1 for keyword in self.bullish_keywords if keyword.lower() in text_lower)
        bearish_count = sum(1 for keyword in self.bearish_keywords if keyword.lower() in text_lower)
        
        total_keywords = bullish_count + bearish_count
        if total_keywords == 0:
            return 0.0
        
        return (bullish_count - bearish_count) / total_keywords
    
    def _extract_stock_symbols(self, text: str) -> List[str]:
        """Extract stock symbols from text using regex patterns."""
        # Common stock symbol patterns
        patterns = [
            r'\$([A-Z]{1,5})',  # $AAPL, $TSLA
            r'\b([A-Z]{1,5})\b',  # AAPL, TSLA (standalone)
        ]
        
        stocks = set()
        for pattern in patterns:
            matches = re.findall(pattern, text.upper())
            for match in matches:
                # Filter out common words that aren't stocks
                if match not in ['THE', 'AND', 'FOR', 'ARE', 'YOU', 'ALL', 'NOW', 'GET', 'HAS', 'HAD', 'WAS', 'HIS', 'HER', 'ITS', 'OUR', 'THEIR']:
                    stocks.add(match)
        
        return list(stocks)
    
    def get_trading_ideas(self, min_mentions: int = 5) -> List[Dict]:
        """
        Extract trading ideas from Reddit sentiment analysis.
        
        Args:
            min_mentions: Minimum mentions to consider a stock
            
        Returns:
            List of trading ideas with sentiment
        """
        sentiment_data = self.get_market_sentiment()
        
        if 'error' in sentiment_data:
            return []
        
        trading_ideas = []
        overall_sentiment = sentiment_data.get('sentiment_score', 0)
        
        for symbol, mentions in sentiment_data.get('mentioned_stocks', {}).items():
            if mentions >= min_mentions:
                # Determine individual stock sentiment (simplified)
                stock_sentiment = 'bullish' if overall_sentiment > 0.1 else 'bearish' if overall_sentiment < -0.1 else 'neutral'
                
                trading_ideas.append({
                    'symbol': symbol,
                    'mentions': mentions,
                    'sentiment': stock_sentiment,
                    'confidence': min(mentions / 20, 1.0),  # Scale confidence by mentions
                    'source': 'reddit_sentiment',
                    'timestamp': datetime.now().isoformat()
                })
        
        return sorted(trading_ideas, key=lambda x: x['mentions'], reverse=True)
    
    def monitor_specific_stocks(self, symbols: List[str], hours_back: int = 6) -> Dict:
        """
        Monitor specific stocks for mentions and sentiment.
        
        Args:
            symbols: List of stock symbols to monitor
            hours_back: How many hours back to analyze
            
        Returns:
            Dictionary with stock-specific sentiment
        """
        if not self.enabled or not self.reddit:
            return {'error': 'Reddit integration not enabled'}
        
        results = {symbol: {
            'mentions': 0,
            'sentiment_score': 0.0,
            'posts': [],
            'comments': []
        } for symbol in symbols}
        
        cutoff_time = datetime.now() - timedelta(hours=hours_back)
        
        for subreddit_name in self.subreddits:
            try:
                subreddit = self.reddit.subreddit(subreddit_name)
                
                for post in subreddit.hot(limit=50):
                    if datetime.fromtimestamp(post.created_utc) < cutoff_time:
                        continue
                    
                    post_text = post.title + ' ' + post.selftext
                    mentioned_symbols = self._extract_stock_symbols(post_text)
                    
                    for symbol in symbols:
                        if symbol in mentioned_symbols:
                            results[symbol]['mentions'] += 1
                            sentiment = self._analyze_text_sentiment(post_text)
                            results[symbol]['sentiment_score'] += sentiment
                            
                            results[symbol]['posts'].append({
                                'title': post.title,
                                'url': f"https://reddit.com{post.permalink}",
                                'sentiment': sentiment,
                                'created': datetime.fromtimestamp(post.created_utc).isoformat()
                            })
                
                time.sleep(1)  # Rate limiting
                
            except Exception as e:
                logger.warning(f"Error monitoring stocks in {subreddit_name}: {e}")
                continue
        
        # Normalize sentiment scores
        for symbol in results:
            if results[symbol]['mentions'] > 0:
                results[symbol]['sentiment_score'] /= results[symbol]['mentions']
        
        return results
    
    def get_strategy_info(self) -> Dict:
        """Get information about the Reddit integration."""
        return {
            'strategy_name': 'Reddit Market Sentiment Analysis',
            'description': 'Monitor trading subreddits for market sentiment and trading ideas',
            'enabled': self.enabled,
            'subreddits': self.subreddits,
            'client_id': self.client_id[:8] + '...' if self.client_id else None,
            'app_name': 'FlimtoFlam'
        }
