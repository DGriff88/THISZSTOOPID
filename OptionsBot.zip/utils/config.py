CONFIG = {
    "max_risk": 40,
    "strategy_toggles": {
        "Zone_Scalping": True,
        "EMA_MACD": True,
        "Yesterday_Setup": True,
        "NoteGPT_FVG": True,
        "Defined_Risk_Spreads": True,
        "Riley_Candle_Trigger": True,
        "EMA_Stoch_Confirmation": True
    }
}
