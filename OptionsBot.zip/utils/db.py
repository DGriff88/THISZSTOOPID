import sqlite3, json, time
from pathlib import Path
from config import DB_PATH

DBP = Path(DB_PATH or "bot_data.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL,
  equity REAL,
  cash REAL,
  long_mv REAL,
  short_mv REAL,
  raw_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_snap_ts ON snapshots(ts);
"""

def _get_conn():
    conn = sqlite3.connect(str(DBP), detect_types=sqlite3.PARSE_DECLTYPES)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    return conn

def init_db():
    DBP.parent.mkdir(parents=True, exist_ok=True)
    with _get_conn() as c:
        c.executescript(SCHEMA)

def insert_snapshot(snapshot: dict, ts: int = None):
    ts = int(ts or time.time())
    bal = snapshot.get("securitiesAccount", {}).get("currentBalances", {}) if snapshot else {}
    cash = float(bal.get("cashBalance") or 0.0)
    long_mv = float(bal.get("longMarketValue") or 0.0)
    short_mv = float(bal.get("shortMarketValue") or 0.0)
    equity = cash + long_mv - short_mv
    raw = json.dumps(snapshot or {})
    with _get_conn() as c:
        c.execute(
            "INSERT INTO snapshots (ts,equity,cash,long_mv,short_mv,raw_json) VALUES (?,?,?,?,?,?)",
            (ts, equity, cash, long_mv, short_mv, raw),
        )
    return equity

def get_equity_series(days: int = 60):
    since = int(time.time()) - int(days) * 86400
    with _get_conn() as c:
        cur = c.execute("SELECT ts,equity FROM snapshots WHERE ts>=? ORDER BY ts ASC", (since,))
        rows = cur.fetchall()
    return [(int(ts), float(eq)) for (ts, eq) in rows]

def get_latest_snapshot():
    with _get_conn() as c:
        cur = c.execute("SELECT ts,equity,cash,long_mv,short_mv,raw_json FROM snapshots ORDER BY ts DESC LIMIT 1")
        row = cur.fetchone()
    if not row:
        return None
    ts, equity, cash, long_mv, short_mv, raw = row
    return {"ts": ts, "equity": equity, "cash": cash, "longMarketValue": long_mv, "shortMarketValue": short_mv, "raw": json.loads(raw or "{}")}
