import time, math, logging
from typing import Any, Dict, List, Optional, cast
import numpy as np
import pandas as pd
from client import api_get, api_post
from data import historical_bars
from db import init_db, insert_snapshot, get_equity_series, get_latest_snapshot
from config import (
    ACCOUNT_ID,
    RISK_PER_TRADE,
    STOP_ATR_MULT,
    MAX_PORTFOLIO_VAR,
    MAX_INTRADAY_LOSS,
    MAX_OPTIONS_DELTA_EXP,
    AUTO_LIQUIDATE,
    OFFLINE_MODE,
    DRY_RUN,
)
from logger import setup_logger
logger = setup_logger("risk")

init_db()

AccountSnapshot = Dict[str, Any]


def safe_float(v: Any, default: float = 0.0) -> float:
    try:
        return float(v)
    except Exception:
        return default

def get_account_snapshot() -> AccountSnapshot:
    # In paper/offline or dry-run, avoid broker calls; synthesize from latest DB if any
    if OFFLINE_MODE or DRY_RUN:
        latest = get_latest_snapshot()
        bal = {
            "cashBalance": float(latest.get("cash", 0.0)) if latest else 0.0,
            "longMarketValue": float(latest.get("longMarketValue", 0.0)) if latest else 0.0,
            "shortMarketValue": float(latest.get("shortMarketValue", 0.0)) if latest else 0.0,
        }
        return {"securitiesAccount": {"currentBalances": bal, "positions": []}}
    try:
        data = api_get(f"/v1/accounts/{ACCOUNT_ID}?fields=positions,balances")
        return data if isinstance(data, dict) else {}
    except Exception:
        logger.exception("Failed fetching account snapshot")
        return {}

def account_equity(snapshot: Optional[AccountSnapshot] = None) -> Optional[float]:
    s: AccountSnapshot = snapshot or get_account_snapshot()
    try:
        bal = s.get("securitiesAccount", {}).get("currentBalances", {})
        cash = safe_float(bal.get("cashBalance", 0.0))
        long_mv = safe_float(bal.get("longMarketValue", 0.0))
        short_mv = safe_float(bal.get("shortMarketValue", 0.0))
        return cash + long_mv - short_mv
    except Exception:
        logger.exception("Failed parsing equity")
        return None

def portfolio_positions(snapshot: Optional[AccountSnapshot] = None) -> List[Dict[str, Any]]:
    s: AccountSnapshot = snapshot or get_account_snapshot()
    try:
        pos = s.get("securitiesAccount", {}).get("positions", []) or []
        return pos if isinstance(pos, list) else []
    except Exception:
        return []

def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high_series: pd.Series = pd.Series(df["high"]).astype(float)
    low_series: pd.Series = pd.Series(df["low"]).astype(float)
    close_series: pd.Series = pd.Series(df["close"]).astype(float)
    part1: pd.Series = high_series - low_series
    part2: pd.Series = (high_series - close_series.shift()).abs()
    part3: pd.Series = (low_series - close_series.shift()).abs()
    true_range: pd.Series = pd.concat([part1, part2, part3], axis=1).max(axis=1)
    result: pd.Series = cast(pd.Series, true_range.rolling(period, min_periods=1).mean())
    return result

def position_size_by_atr(symbol, risk_per_trade=None, stop_atr_mult=None, lookback_days=5):
    risk_per_trade = float(risk_per_trade or RISK_PER_TRADE)
    stop_atr_mult = float(stop_atr_mult or STOP_ATR_MULT)
    equity = account_equity()
    if equity is None or equity <= 0:
        # fallback when offline/no broker
        equity = 10000.0
    df = historical_bars(symbol, period=f"{lookback_days}d", interval="5m")
    if df.empty or "close" not in df:
        return 1
    a_series: pd.Series = pd.Series(atr(df, period=14))
    a = float(a_series.iloc[-1])
    if a <= 0 or np.isnan(a):
        return 1
    risk_dollars = equity * risk_per_trade
    stop_distance = a * stop_atr_mult
    raw_qty = int(risk_dollars / stop_distance) if stop_distance > 0 else 1
    return max(int(raw_qty), 1)

def portfolio_var(returns, confidence: float = 0.95) -> Optional[float]:
    arr = np.asarray(list(returns), dtype=float)
    if arr.size < 2:
        return None
    q: float = float(1.0 - float(confidence))
    return -float(pd.Series(arr).quantile(q))

def calc_portfolio_var_lookback(days: int = 60):
    rows_list: List[tuple[int, float]] = [(int(ts), float(eq)) for (ts, eq) in get_equity_series(days)]
    if len(rows_list) < 2:
        return None
    df = pd.DataFrame(
        {
            "ts": [ts for (ts, _) in rows_list],
            "equity": [eq for (_, eq) in rows_list],
        }
    )
    df["dt"] = pd.to_datetime(df["ts"], unit="s")
    df.set_index("dt", inplace=True)
    daily = df["equity"].resample("1D").last().dropna()
    if len(daily) < 2:
        return None
    returns = daily.pct_change().dropna().values
    if returns.size < 2:
        return None
    var95 = -float(pd.Series(returns).quantile(0.05))
    return float(var95)

def estimate_options_delta_exposure():
    pos = portfolio_positions()
    total_delta = 0.0
    for p in pos:
        inst = p.get("instrument", {}) or {}
        asset_type = (inst.get("assetType") or inst.get("asset_type") or "").upper()
        if asset_type == "OPTION":
            long_q = safe_float(p.get("longQuantity", 0))
            short_q = safe_float(p.get("shortQuantity", 0))
            net_contracts = long_q - short_q
            delta = safe_float(inst.get("delta", 0.0))
            total_delta += delta * net_contracts * 100
    return total_delta

def persist_account_snapshot(snapshot=None):
    snap = snapshot or get_account_snapshot()
    try:
        eq = insert_snapshot(snap)
        logger.debug("Persisted snapshot equity=%.2f", eq)
        return True
    except Exception:
        logger.exception("Failed to persist snapshot")
        return False

def check_risk_limits(snapshot=None, env_config=None):
    reasons = []
    snap = snapshot or get_account_snapshot()
    equity = account_equity(snap)
    if equity is None:
        reasons.append("equity_unknown")
        return False, reasons

    pv = calc_portfolio_var_lookback()
    max_var = float(env_config.get("MAX_PORTFOLIO_VAR", MAX_PORTFOLIO_VAR)) if env_config else float(MAX_PORTFOLIO_VAR)
    if pv is not None and max_var is not None and pv > max_var:
        reasons.append(f"var_exceeded:{pv:.3f}>{max_var}")

    max_intraday = float(env_config.get("MAX_INTRADAY_LOSS", MAX_INTRADAY_LOSS)) if env_config else float(MAX_INTRADAY_LOSS)
    try:
        bal = snap.get("securitiesAccount", {}).get("currentBalances", {})
        cash = safe_float(bal.get("cashBalance", 0.0))
        mv = safe_float(bal.get("longMarketValue", 0.0))
        net_equity = cash + mv
        if net_equity < equity * (1 - max_intraday):
            reasons.append("intraday_loss_exceeded")
    except Exception:
        pass

    try:
        delta_exp = estimate_options_delta_exposure()
        max_delta = float(env_config.get("MAX_OPTIONS_DELTA_EXP", MAX_OPTIONS_DELTA_EXP)) if env_config else float(MAX_OPTIONS_DELTA_EXP)
        if abs(delta_exp) > max_delta:
            reasons.append(f"delta_exposure:{delta_exp:.1f}>{max_delta}")
    except Exception:
        pass

    ok = len(reasons) == 0
    return ok, reasons

def enforce_limits(auto_liquidate=False):
    ok, reasons = check_risk_limits()
    if ok:
        logger.debug("Risk engine: all checks passed")
        return True, []
    logger.warning("Risk engine breach: %s", reasons)
    if auto_liquidate or AUTO_LIQUIDATE:
        logger.warning("Auto-liquidation enabled: attempting reduction")
        pos = portfolio_positions()
        for p in pos:
            inst = p.get("instrument", {}) or {}
            symbol = inst.get("symbol")
            long_q = safe_float(p.get("longQuantity", 0))
            short_q = safe_float(p.get("shortQuantity", 0))
            net = int(long_q - short_q)
            if net == 0:
                continue
            side = "Sell" if net > 0 else "Buy"
            qty = abs(net)
            payload = {
                "accountId": ACCOUNT_ID,
                "orderType": "Market",
                "symbol": symbol,
                "quantity": qty,
                "instruction": side,
            }
            try:
                api_post("/v1/accounts/orders", payload)
                logger.info("Submitted reduction order %s %s qty=%s", symbol, side, qty)
                time.sleep(0.3)
            except Exception:
                logger.exception("Failed to submit reduction for %s", symbol)
        return False, reasons
    return False, reasons
