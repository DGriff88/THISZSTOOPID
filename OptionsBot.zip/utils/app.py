from flask import Flask, request, redirect
import os
from urllib.parse import urlencode, quote_plus
from dotenv import load_dotenv
from requests_oauthlib import OAuth2Session
from auth import exchange_code_for_token

# Ensure env is loaded when running directly
load_dotenv()

# Schwab API credentials and URLs
CLIENT_ID = os.getenv('CLIENT_ID')
AUTH_URL = os.getenv('AUTH_URL')
TOKEN_URL = os.getenv('TOKEN_URL')
CALLBACK_URL = os.getenv('CALLBACK_URL')


app = Flask(__name__)

@app.route('/')
def root():
    if not CLIENT_ID or not AUTH_URL or not CALLBACK_URL:
        return 'Missing CLIENT_ID/AUTH_URL/CALLBACK_URL in environment.'
    # Minimal auth start link
    scope = os.getenv('SCOPE', 'read write')
    oauth = OAuth2Session(CLIENT_ID, redirect_uri=CALLBACK_URL, scope=scope)
    auth_url, state = oauth.authorization_url(AUTH_URL)
    return redirect(auth_url)

@app.route('/callback')
def callback():
    code = request.args.get('code')
    if code:
        authorization_response = request.url
        exchange_code_for_token(authorization_response)
        return 'OK'
    return 'Error: No code received'
