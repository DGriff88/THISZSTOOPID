# run_live.py — Paper/Live runner with LIVE tripwire
# Works with: data.py, strategies.py (ema_crossover_signal), orders.py, risk.py, db.py,
#             config.py (.env), rules_gate.py, logger.py, strategies_seasonal.py, options_strategy.py, reddit_integration.py

import os
import time
from datetime import datetime

from data import historical_bars
from strategies import ema_crossover_signal
from orders import place_equity_market, place_equity_size_by_atr
from risk import check_risk_limits, enforce_limits, persist_account_snapshot
from db import init_db
from config import (
    KILL_SWITCH,
    AUTO_LIQUIDATE,
    RISK_PER_TRADE,
    STOP_ATR_MULT,
    SNAPSHOT_INTERVAL_SEC,
    OFFLINE_MODE,
    DRY_RUN,
    SEASONAL_ENABLED,
    OPTIONS_ENABLED,
    REDDIT_ENABLED,
    SEASONAL_STOCKS,
    SEASONAL_START_DATES,
)
from rules_gate import allow_order, record_order
from logger import setup_logger

# Import new strategy modules
try:
    from strategies_seasonal import SeasonalStrategy
    from options_strategy import OptionsStrategy
    from reddit_integration import RedditIntegration
except ImportError as e:
    print(f"Warning: Could not import strategy modules: {e}")
    SeasonalStrategy = None
    OptionsStrategy = None
    RedditIntegration = None

logger = setup_logger("run_live")

# === YOUR WATCHLIST ===
# Use straight quotes. Example: ["AAPL", "SOFI", "SCHD"]
SYMBOLS = ["ETH-USD", "ETHZ", "AAPL", "SOFI", "SCHD"]

# Initialize strategy objects
seasonal_strategy = None
options_strategy = None
reddit_integration = None

if SEASONAL_ENABLED and SeasonalStrategy:
    try:
        seasonal_config = {
            'SEASONAL_STOCKS': SEASONAL_STOCKS,
            'SEASONAL_START_DATES': SEASONAL_START_DATES,
            'MEMORIAL_DAY_START': '05-25',
            'LABOR_DAY_END': '09-01'
        }
        seasonal_strategy = SeasonalStrategy(seasonal_config)
        logger.info("Seasonal strategy initialized")
    except Exception as e:
        logger.error(f"Failed to initialize seasonal strategy: {e}")

if OPTIONS_ENABLED and OptionsStrategy:
    try:
        options_config = {
            'OPTIONS_ENABLED': OPTIONS_ENABLED,
            'OPTIONS_STRATEGY': 'calls',
            'OPTIONS_EXPIRY_DAYS': 45,
            'OPTIONS_DELTA_TARGET': 0.30
        }
        options_strategy = OptionsStrategy(options_config)
        logger.info("Options strategy initialized")
    except Exception as e:
        logger.error(f"Failed to initialize options strategy: {e}")

if REDDIT_ENABLED and RedditIntegration:
    try:
        reddit_config = {
            'REDDIT_ENABLED': REDDIT_ENABLED,
            'REDDIT_CLIENT_ID': '8jkzCTWZ4tMiDAsqu_2ltQ',
            'REDDIT_CLIENT_SECRET': 'EqvLbAs-zkJemu-yjlvg1A7zUanfBg',
            'REDDIT_REDIRECT_URI': 'http://localhost',
            'REDDIT_USER_AGENT': 'Schwabbot/1.0'
        }
        reddit_integration = RedditIntegration(reddit_config)
        logger.info("Reddit integration initialized")
    except Exception as e:
        logger.error(f"Failed to initialize Reddit integration: {e}")

# === LIVE TRIPWIRE ===
def live_tripwire():
    """
    Blocks startup if BOTH (OFFLINE_MODE == False) and (DRY_RUN == False),
    unless you explicitly set ALLOW_LIVE=true in .env.
    """
    if not OFFLINE_MODE and not DRY_RUN:
        msg = ">>> LIVE ORDERS ENABLED <<< (OFFLINE_MODE=false & DRY_RUN=false)"
        for _ in range(3):
            logger.critical(msg)
            time.sleep(0.3)
        allow = (os.getenv("ALLOW_LIVE", "").strip().lower() in ("1", "true", "yes", "y", "live"))
        if not allow:
            logger.critical("Startup BLOCKED. Set ALLOW_LIVE=true in .env to proceed.")
            raise SystemExit(2)

def main_loop(poll_interval: int = 30):
    init_db()
    last_snapshot = 0
    snap_every = int(SNAPSHOT_INTERVAL_SEC or 300)

    logger.info("Starting main loop (OFFLINE_MODE=%s)", OFFLINE_MODE)

    if KILL_SWITCH:
        logger.error("Kill switch enabled. Exiting.")
        return

    while True:
        # Risk gate (skipped in Paper Mode)
        if OFFLINE_MODE:
            risk_ok, reasons = True, []
        else:
            risk_ok, reasons = check_risk_limits()

        if not risk_ok:
            logger.warning("Risk gate failed: %s", reasons)
            if AUTO_LIQUIDATE:
                try:
                    enforce_limits(auto_liquidate=True)
                except Exception as e:
                    logger.exception("Auto-liquidate failed: %s", e)
            time.sleep(poll_interval)
            continue

        # Per-symbol work
        for sym in SYMBOLS:
            try:
                df = historical_bars(sym, period="1d", interval="1m")
                if df is None or df.empty:
                    logger.debug("No bars for %s", sym)
                    continue

                # Get current price for strategies
                current_price = df['close'].iloc[-1] if not df.empty else None
                
                # Strategy signals
                signals = {
                    'ema': {'buy': False, 'sell': False},
                    'seasonal': {'buy': False, 'sell': False},
                    'options': {'buy': False, 'sell': False}
                }
                
                # EMA Crossover Signal (original strategy)
                buy_sig, sell_sig = ema_crossover_signal(df)
                signals['ema']['buy'] = bool(buy_sig.iloc[-1]) if not buy_sig.empty else False
                signals['ema']['sell'] = bool(sell_sig.iloc[-1]) if not sell_sig.empty else False
                
                # Seasonal Strategy Signal
                if seasonal_strategy and SEASONAL_ENABLED:
                    try:
                        seasonal_buy, seasonal_sell, seasonal_meta = seasonal_strategy.seasonal_signal(df, sym)
                        signals['seasonal']['buy'] = seasonal_buy
                        signals['seasonal']['sell'] = seasonal_sell
                        
                        if seasonal_buy or seasonal_sell:
                            logger.info("Seasonal signal for %s: buy=%s, sell=%s, meta=%s", 
                                      sym, seasonal_buy, seasonal_sell, seasonal_meta)
                    except Exception as e:
                        logger.warning("Seasonal strategy error for %s: %s", sym, e)
                
                # Options Strategy Signal
                if options_strategy and OPTIONS_ENABLED and current_price:
                    try:
                        options_buy, options_sell, options_meta = options_strategy.generate_options_signals(df, sym, current_price)
                        signals['options']['buy'] = options_buy
                        signals['options']['sell'] = options_sell
                        
                        if options_buy or options_sell:
                            logger.info("Options signal for %s: buy=%s, sell=%s, meta=%s", 
                                      sym, options_buy, options_sell, options_meta)
                    except Exception as e:
                        logger.warning("Options strategy error for %s: %s", sym, e)
                
                # Combine signals (any strategy can trigger)
                any_buy = any(sig['buy'] for sig in signals.values())
                any_sell = any(sig['sell'] for sig in signals.values())
                
                # BUY Decision
                if any_buy:
                    allowed, why = allow_order(sym, "Buy")
                    if not allowed:
                        logger.info("Blocked by playbook rule (%s) for %s Buy", why, sym)
                    else:
                        # Log which strategies triggered
                        triggered_strategies = [name for name, sig in signals.items() if sig['buy']]
                        logger.info("Buy signal for %s from strategies: %s", sym, triggered_strategies)
                        
                        try:
                            place_equity_size_by_atr(
                                sym,
                                risk_per_trade=RISK_PER_TRADE,
                                stop_atr_mult=STOP_ATR_MULT,
                            )
                            record_order()
                        except Exception as e:
                            logger.exception("Buy sizing/order failed for %s: %s", sym, e)

                # SELL Decision
                elif any_sell:
                    allowed, why = allow_order(sym, "Sell")
                    if not allowed:
                        logger.info("Blocked by playbook rule (%s) for %s Sell", why, sym)
                    else:
                        # Log which strategies triggered
                        triggered_strategies = [name for name, sig in signals.items() if sig['sell']]
                        logger.info("Sell signal for %s from strategies: %s", sym, triggered_strategies)
                        
                        try:
                            # simple market-size sell (example: -1 means "all" in your orders.py logic)
                            place_equity_market(sym, -1)
                            record_order()
                        except Exception as e:
                            logger.exception("Sell order failed for %s: %s", sym, e)

            except Exception as e:
                logger.exception("Error processing %s: %s", sym, e)

        # Reddit sentiment analysis (every 4 hours)
        if reddit_integration and REDDIT_ENABLED:
            try:
                current_hour = datetime.now().hour
                if current_hour % 4 == 0:  # Every 4 hours
                    logger.info("Running Reddit sentiment analysis...")
                    sentiment_data = reddit_integration.get_market_sentiment(hours_back=6)
                    
                    if 'error' not in sentiment_data:
                        logger.info("Reddit sentiment: score=%.2f, posts=%d, comments=%d", 
                                  sentiment_data.get('sentiment_score', 0),
                                  sentiment_data.get('total_posts', 0),
                                  sentiment_data.get('total_comments', 0))
                        
                        # Get trading ideas from Reddit
                        trading_ideas = reddit_integration.get_trading_ideas(min_mentions=3)
                        if trading_ideas:
                            logger.info("Reddit trading ideas: %s", 
                                      [f"{idea['symbol']}({idea['mentions']})" for idea in trading_ideas[:5]])
            except Exception as e:
                logger.warning("Reddit sentiment analysis failed: %s", e)
        
        # Periodic account snapshot (live only)
        if not OFFLINE_MODE:
            now = int(time.time())
            if now - last_snapshot >= snap_every:
                try:
                    persist_account_snapshot()
                except Exception:
                    logger.exception("Snapshot failed")
                last_snapshot = now

        time.sleep(poll_interval)


if __name__ == "__main__":
    try:
        live_tripwire()  # hard stop if live without ALLOW_LIVE
        main_loop()
    except KeyboardInterrupt:
        logger.info("Stopped by user")
