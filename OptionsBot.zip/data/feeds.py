# data.py — clean replacement
import os
import logging
import pandas as pd

logger = logging.getLogger(__name__)

_CANON = ("open", "high", "low", "close", "volume")

def _normalize(df: pd.DataFrame) -> pd.DataFrame:
    """Coerce to canonical OHLCV with datetime index."""
    if df is None or getattr(df, "empty", True):
        return pd.DataFrame(columns=_CANON)

    # yfinance sometimes returns a MultiIndex columns like ('Open','AAPL')
    if isinstance(df.columns, pd.MultiIndex):
        try:
            df = df.droplevel(-1, axis=1)
        except Exception:
            pass

    # standardize column names
    cols_lower = {c.lower(): c for c in df.columns}
    out = pd.DataFrame(index=df.index)
    for k in _CANON:
        src = None
        # exact lower match
        if k in cols_lower:
            src = cols_lower[k]
        # Capitalized common names (Open, High, Low, Close, Volume)
        elif k.capitalize() in df.columns:
            src = k.capitalize()
        # Schwab-style keys
        elif k + "Price" in df.columns:
            src = k + "Price"

        if src is not None:
            out[k] = pd.to_numeric(df[src], errors="coerce")
        else:
            out[k] = pd.NA

    out.index.name = "datetime"
    out = out.sort_index()
    out = out.dropna(subset=["close"])
    return out


def historical_bars(symbol: str, period: str = None, interval: str = None) -> pd.DataFrame:
    """
    Return OHLCV bars for `symbol` with canonical columns and datetime index.
    Respects env overrides:
      PERIOD   (default '5d')
      INTERVAL (default '1m')
      MIN_BARS (default 30)
      DATA_PROVIDER ('yfinance' or 'schwab', default 'yfinance')
    """
    period = (period or os.getenv("PERIOD", "5d")).strip()
    interval = (interval or os.getenv("INTERVAL", "1m")).strip()
    min_bars = int(os.getenv("MIN_BARS", "30"))
    provider = os.getenv("DATA_PROVIDER", "yfinance").lower()

    if provider == "yfinance":
        try:
            import yfinance as yf  # lazy import

            df = yf.download(
                symbol,
                period=period,
                interval=interval,
                progress=False,
                prepost=False,
                auto_adjust=True,
                group_by="ticker",
            )

            # yfinance sometimes returns empty for 1m/1d during off hours; try a safe fallback
            if (df is None or getattr(df, "empty", True)) and interval == "1m":
                logger.debug(
                    "yfinance empty for %s %s %s; falling back to 5m/5d",
                    symbol, period, interval
                )
                df = yf.download(
                    symbol,
                    period="5d",
                    interval="5m",
                    progress=False,
                    prepost=False,
                    auto_adjust=True,
                    group_by="ticker",
                )

            norm = _normalize(df)
            if norm.empty or len(norm) < min_bars:
                return norm.iloc[0:0]  # explicit empty DF with canonical columns
            return norm

        except Exception as e:
            logger.exception("yfinance bars failed: %s", e)
            return pd.DataFrame(columns=_CANON)

    # ---- Schwab path ----
    try:
        # expects client.api_get() to be available after OAuth
        from client import api_get  # lazy import to avoid circulars

        params = {"symbol": symbol, "period": period, "interval": interval}
        data = api_get(f"/v1/markets/history/{symbol}", params=params)

        candles = data.get("candles") or data.get("candlestick") or data.get("data") or []
        if not candles:
            return pd.DataFrame(columns=_CANON)

        df = pd.DataFrame(candles)

        # coerce time to datetime index
        if "datetime" in df.columns:
            df["datetime"] = pd.to_datetime(df["datetime"], unit="ms", errors="coerce")
        elif "time" in df.columns:
            df["datetime"] = pd.to_datetime(df["time"], unit="ms", errors="coerce")
        else:
            # last resort: if there is a 'date' string
            if "date" in df.columns:
                df["datetime"] = pd.to_datetime(df["date"], errors="coerce")

        if "datetime" in df.columns:
            df.set_index("datetime", inplace=True)

        # Schwab naming → canon
        rename = {
            "openPrice": "open",
            "highPrice": "high",
            "lowPrice": "low",
            "closePrice": "close",
            "open": "open",
            "high": "high",
            "low": "low",
            "close": "close",
            "volume": "volume",
        }
        df.rename(columns=rename, inplace=True)

        norm = _normalize(df)
        if norm.empty or len(norm) < min_bars:
            return norm.iloc[0:0]
        return norm

    except Exception as e:
        logger.exception("schwab history failed: %s", e)
        return pd.DataFrame(columns=_CANON)

def get_historical_data(symbol, period='30d', interval='1h'):
    # Dummy historical data (replace with yfinance, API, or real fetch logic later)
    import pandas as pd
    import numpy as np
    from datetime import datetime, timedelta

    date_range = pd.date_range(end=datetime.now(), periods=30, freq='h')
    prices = np.random.uniform(low=100, high=200, size=len(date_range))

    df = pd.DataFrame({'datetime': date_range, 'close': prices})
    return df

